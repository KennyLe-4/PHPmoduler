
<?php
// for-loop that counts up to 9.
for($i=1; $i <=9; $i++)
{
    $sum += $i;
    echo $i . "<br>";
    
}

echo "Ferdig å telle!" . "<br>";
echo "Summen av alle tallene er: " . ($sum);
?>

