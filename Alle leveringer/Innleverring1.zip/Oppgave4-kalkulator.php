<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body>



<!-- Kalkulator -->
<h1>Nedenfor ser du summen, differansen og gjennomsnittet av ulike tall  </h1>
<?php
$tall1 = 15;
$tall2 = 7;
$sum = $tall1 + $tall2; 
echo "Summen av 15 + 7 blir " . $sum; 
?>

<br>

<?php
$tall1 = 15;
$tall2 = 7;
$sum = $tall1 - $tall2; 
echo "Differansen mellom 15 - 7 blir " . $sum; 
?>

<br>

<?php
$tall1 = 15;
$tall2 = 7;
$sum = ($tall1 + $tall2) / 2; 
echo "Gjennomsnittet  mellom 15 og 7 blir " . $sum;    
?>








</body>
</html>