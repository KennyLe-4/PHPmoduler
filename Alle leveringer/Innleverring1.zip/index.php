<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href=//styles.css">

</head>
<body>
    <h1>Velkommen til siden min</h1>
    <h2>Nedenfor kan du se oppgavene mine</h2>
    <ul>
    <li><a href="https://discord.com/channels/1003702471513878568/1003702471958466697">Oppgave 1 - Discord</a></li>
    <br>
    <li><a href="info.php"> Oppgave 2 - PHP informasjon </a></li>
    <br>
    <li><a href="Oppgave3-navn.php"> Oppgave 3 - Navn</a></li>
    <br>
    <li><a href="Oppgave4-kalkulator.php"> Oppgave 4 - Kalkulator</a></li>
    <br>
    <li> <a href="Sekunder.php"> Oppgave 5 - Omregning av sekunder</a></li>
    </ul>
    
    
   
   
    
</body>
</html>