<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$antall_sekunder = 4400;

$hours = ($antall_sekunder/3600) % 24; 
$minutter = ($antall_sekunder/60) % 60; 
$sekunder = $antall_sekunder % 60; 
// Gir variable verdier.?>

<p>For å konvertere 4400 sekunder til timer, minutter og sekunder har jeg brukt funksjonen gmdate().
    <?php echo gmdate("H:i:s", $antall_sekunder);?> 
</p><br>
<p>Jeg kom fram til av svaret til ved hjelp av modulo operatoren.</p>






</body>
</html>