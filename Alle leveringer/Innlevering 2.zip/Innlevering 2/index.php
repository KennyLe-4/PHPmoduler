<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>Velkommen til siden min</h1>
    <h2>Nedenfor kan du se oppgavene mine</h2>

    <ul>
    <li><a href="Oppgave1-SjekkAvEtternavn.php">Oppgave 1 - Sjekk av alder</a></li>
    <br>
    <li><a href="Oppgave2-FjernKode.php"> Oppgave 2 - Fjern kode </a></li>
    <br>
    <li><a href="Oppgave3-FinnOrd.php"> Oppgave 3 - Finn ord</a></li>
    <br>
    <li><a href="Oppgave4-Alder.php"> Oppgave 4 - Alder</a></li>
    <br>
    <li> <a href="Oppgave5-PassordGenerator.php"> Oppgave 5 - Passordgenerator</a></li>
    </ul>
    
    
    
</body>
</html>