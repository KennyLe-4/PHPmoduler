<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>Back up database via phpMyAdmin</h3>
    <p>1. Gå på "export" for å exporte databasen.</p>
    <p>2. Lagre filen et sted du finner den på pcn</p>
    <p>3. Demonstrere ved å slette database. Lage ny database med samme navn som den du exportet. Deretter bruke import funksjonen og legge til filen.</p>
    <p>4. Kan demonstrer ved å slette og kjøre back up av databasen "test"</p>



</body>
</html>