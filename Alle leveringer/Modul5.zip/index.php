
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../style/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,100&display=swap" rel="stylesheet">



</head>
<div class = "center"> 
    <h1>Velkommen til siden min</h1>
    <h2>Nedenfor kan du se oppgavene mine</h2>
    <a href="opg5.1.php"> Oppgave 1 - standardavvik </a>
    <br>
    <a href="opg5.2.php">Oppgave 2 - plan for filstruktur og klassebibliotek </a>
    <br>
    <a href="Opg5.3.php">Oppgave 3 -  kommentering </a>
    <br>
    <a href="opg5.4.php">Oppgave 4 - god programmeringsskikk  </a>
    <br>
    <a href="opg5.5.php">Oppgave 5 - kryptering </a>
    <br>
   

</div>
<body>
    
</body>
</html>