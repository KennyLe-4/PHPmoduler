<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../style/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,100&display=swap" rel="stylesheet">



</head>
<div class = "center"> 
    <h1>Velkommen til siden min</h1>
    <h2>Nedenfor kan du se oppgavene mine</h2>

    <a href="Oppgave9-1.php">Oppgave 1 - Lese informasjon av filer</a>
    <br>
    <a href="Oppgave9-2.php">Oppgave 2 - Loggfunksjon</a>
    <br>
    <a href="Oppgave9-3.php">Oppgave 3 - Last opp fil</a>
    <br>
    <a href="Oppgave9-4.php">Oppgave 4 - Nedlasting av fil</a>
    <br>
    <a href="Oppgave9-5.php">Oppgave 5 - Faktura</a>
    <br>
</div>
<body>
    
</body>
</html>