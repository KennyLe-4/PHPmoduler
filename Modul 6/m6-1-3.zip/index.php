
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../style/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,100&display=swap" rel="stylesheet">



</head>
<div class = "center"> 
    <h1>Velkommen til siden min</h1>
    <h2>Nedenfor kan du se oppgavene mine</h2>

    <a href="tests.php">Oppgave 1-3 - lage klasse, arv og tilgangskontroll og automatisering.</a>
    <p>Koden ligger i mappen "includes" under filnavnet "user.inc.php". </p>
    <br>
    <a href="Opg4.php">Oppgave 4 - Planlegging av system </a>
    <br>
    <a href="Opg5.php">Oppgave 5 - lynmeldinger</a>

</div>
<body>
    
</body>
</html>